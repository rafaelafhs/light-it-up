class Pedra {
  float x, y;

  Pedra(float x, float y) {
    this.x = x;
    this.y = y;
  }

  void desenhar() {
    image(pedrinha, x, y, 40, 40); // desenha a pedra na posição guardada
  }
}
