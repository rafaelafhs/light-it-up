class Velho {

  float x;
  float y;
  float velx;
  boolean ajuda;

  Velho (float x, float y, float velx) {
    this.x = x;
    this.y = y;
    this.velx = velx;
    this.ajuda= false;
  }

  void moveredesenhar () {
  // inverte a direção se bater na borda
  if (x + velx < 0 || x + velx > width - 100) {
    velx *= -1;
  }

  // desenha baseado na direção
  if (velx > 0) {
    image(velho_direita, x, y, 135, 150);
  } else {
    image(velho_esquerda, x, y, 135, 150);
  }

  x += velx;
}
void perseguir(float tx, float ty) {
  PVector alvo   = new PVector(tx, ty);
  PVector pos    = new PVector(x,  y);
  PVector direcc = PVector.sub(alvo, pos).normalize().mult(1.5); // velocidade
  velx = direcc.x;
  float vely = direcc.y;
  y += vely;
}
}
