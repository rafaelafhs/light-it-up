// FALTA TODOS OS NIVEIS ++
// FALTA GANHAR - SISTEMA
// FALTA COLOCAR VELAS

// BOTOES
Botoes botaoMenu, botaoNiveis, botaoInstrucoes, botaoBack, botaoInicio, jOutraVez, jNext;
Botoes botaoGato, botaoPato, botaoPenguim, botaoJogar;
Botoes n1, n2, n3;

// IMAGENS
PImage gato_frente, gato_costas, gato_direita, gato_esquerda, bgato;
PImage pato_frente, pato_costas, pato_direita, pato_esquerda, bpato;
PImage penguim_frente, penguim_costas, penguim_direita, penguim_esquerda, bpenguim;
PImage vela_acesa, vela_apagada;
PImage velho_frente, velho_costas, velho_direita, velho_esquerda;
PImage inicio, botaoI, screen, carascreen, play, niveis, howto, back,
  b1, b2, b3, again, bagain, next, bnext;
PImage pedrinha;
PImage maskLabirinto;
// CLASSES
Gato gato;
Pato pato;
Penguim penguim;
Velho velho;
Pedra [] pedras = new Pedra [5];
Vela [] velas = new Vela [3];

// OUTROS
int tela = 0;
String personagemEscolhido = "";
float tempo = 100; // inicio da energia
int nivel = 1;
final float SHAKE_MAG    = 5;   // desvio máximo em px
final int   SHAKE_FRAMES = 12;
int tremorCounter = 0;
void setup () {
  size (1300, 800);
  // IMAGENS
  gato_frente = loadImage ("gato_frente.png");
  gato_costas = loadImage ("gato_costas.png");
  gato_direita = loadImage ("gato_direita.png");
  gato_esquerda = loadImage ("gato_esquerda.png");
  pato_frente = loadImage ("pato_frente.png");
  pato_costas = loadImage ("pato_costas.png");
  pato_direita = loadImage ("pato_direita.png");
  pato_esquerda = loadImage ("pato_esquerda.png");
  penguim_frente = loadImage ("pinguim_frente.png");
  penguim_costas = loadImage ("pinguim_costas.png");
  penguim_direita = loadImage ("pinguim_direita.png");
  penguim_esquerda = loadImage ("pinguim_esquerda.png");
  vela_acesa = loadImage ("vela_acesa.png");
  vela_apagada = loadImage ("vela_apagada.png");
  velho_frente = loadImage ("velho_frente.png");
  velho_costas = loadImage ("velho_costas.png");
  velho_direita = loadImage ("velho_direita.png");
  velho_esquerda = loadImage ("velho_esquerda.png");
  pedrinha = loadImage ("pedra.png");

  inicio = loadImage ("main screen.jpg");
  botaoI = loadImage ("botão_main.png");
  screen = loadImage ("loadingscreen.jpg");
  carascreen = loadImage ("characterscreen.jpg");
  play = loadImage ("play_btn.png");
  niveis = loadImage ("levels_btn.png");
  howto = loadImage ("howtoplay_btn.png");
  back = loadImage ("back_button.png");
  b1 = loadImage ("lvl1_btn.png");
  b2 = loadImage ("lvl2_btn.png");
  b3 = loadImage ("lvl3_btn.png");
  bgato = loadImage ("gato_btn.png");
  bpato = loadImage ("pato_btn.png");
  bpenguim = loadImage ("pingu_btn.png");
  again = loadImage ("lost_level.jpg");
  bagain = loadImage ("lost_btn.png");
  next = loadImage ("passed_level.jpg");
  bnext = loadImage ("nextlevel_btn.png");
  maskLabirinto= loadImage("labirinto_escuro.png");

  gato = new Gato (100, 100, 10, 70, 80);
  pato = new Pato (180, 100, 10, 70, 80);
  penguim = new Penguim (260, 100, 15, 70, 80);
  velho = new Velho (width / 2, random (50, height - 50), 2);

  // BOTOES
  botaoMenu = new Botoes (width / 2 - 150, height / 2 - 150, 70, 250, play);
  botaoNiveis = new  Botoes (width / 2 - 150, height / 2, 70, 250, niveis);
  botaoInstrucoes = new Botoes (width / 2 - 150, height / 2 + 150, 70, 250, howto);
  n1 = new Botoes (width / 2 - 150, height / 2 - 150, 70, 250, b1);
  n2 = new Botoes (width / 2 - 150, height / 2, 70, 250, b2);
  n3 = new Botoes (width / 2 - 150, height / 2 + 150, 70, 250, b3);
  botaoGato = new Botoes (width / 2 - 480, height / 2 + 190, 80, 200, bgato);
  botaoPato = new Botoes (width / 2 - 105, height / 2 + 190, 80, 200, bpato);
  botaoPenguim = new Botoes (width / 2 + 270, height / 2 + 190, 80, 200, bpenguim);
  botaoJogar = new Botoes (width / 2 - 105, height / 2 + 290, 80, 200, play);
  botaoBack = new Botoes (20, 20, 40, 40, back);
  botaoInicio = new Botoes (width / 2 - 265, height / 2 + 170, 103, 520, botaoI);
  jOutraVez = new Botoes (width / 2 - 200, height / 2 - 20, 60, 370, bagain);
  jNext = new Botoes (width / 2 - 200, height / 2 - 20, 60, 370, bnext);

  inicializarJogo ();
}
// inicializar o jogo
// contem todas as repeticoes precisas e todos os seus valores
void inicializarJogo () {
  // repeticao e declaracao das pedras
  for (int p = 0; p < pedras.length; p++) {
    pedras[p] = new Pedra (random(50, width - 50), random(50, height - 50));
  }

  for (int i = 0; i < velas.length; i++) {
    velas[i] = new Vela(random(50, width - 50), random(50, height - 50));
  }
  // velho só para o nível 3
  if (nivel == 3) velho = new Velho(width/2, random(50, height-50), 2);
  else            velho = null;        // não existe nos outros níveis
}
//velho.moveredesenhar ();


void draw () {
  if (tela == 0) {
    desenharInicial ();
  } else if (tela == 1) { // menu
    desenharMenu ();
  } else if (tela == 2) { // menu niveis
    desenharNiveis ();
  } else if (tela == 3) { // instrucoes / how to play
    desenharInstrucoes ();
  } else if (tela == 4) { // nivel 1
    desenharNivel1 ();
  } else if (tela == 5) { // diferentes personagens
    desenharPersonagens ();
  } else if (tela == 6) { // game over
    desenharPerder ();
  } else if (tela == 7) { // next level
    desenharProxNiv ();
  } else if (tela == 8) { // nivel 2
    desenharNivel2 ();
  } else if (tela == 9) { // nivel 3
    desenharNivel3 ();
  }
}

void mousePressed() {
  if (tela == 0 && botaoInicio.estaSobre ()) {
    tela = 1;
  } else if (tela == 1 && botaoMenu.estaSobre ()) {
    tela = 5;
  } else if (tela == 5) {
    if (botaoGato.estaSobre()) {
      personagemEscolhido = "gato";
    } else if (botaoPato.estaSobre()) {
      personagemEscolhido = "pato";
    } else if (botaoPenguim.estaSobre()) {
      personagemEscolhido = "penguim";
    } else if (tela == 5 && botaoJogar.estaSobre() && !personagemEscolhido.equals ("")) {
      tela = 4;
    }
  } else if (tela == 1 && botaoNiveis.estaSobre ()) {
    tela = 2; // Vai para a tela de níveis
  } else if (tela == 2 && botaoBack.estaSobre ()) {
    tela = 1; // Volta para o menu
  } else if (tela == 1 && botaoInstrucoes.estaSobre ()) {
    tela = 3; // Vai para as instruções
  } else if (tela == 3 && botaoBack.estaSobre ()) {
    tela = 1; // Volta para o menu
  } else if (tela == 2 && n1.estaSobre ()) { // Seleção do nível 1
    selecionarNivel(1);
  } else if (tela == 2 && n2.estaSobre ()) { // Seleção do nível 2
    selecionarNivel(2);
  } else if (tela == 2 && n3.estaSobre ()) { // Seleção do nível 3
    selecionarNivel(3);
  } else if (tela == 5 && botaoBack.estaSobre ()) { // Se estiver na tela de personagens e carregar no botão voltar
    tela = 1; // Volta para o menu
  } else if (tela == 6 && jOutraVez.estaSobre ()) { // Tela de game over e botão tentar novamente
    inicializarJogo (); // Reinicia o jogo
    if (nivel == 1) {
      tela = 4;
    } else if (nivel == 2) {
      tela = 8;
    } else if (nivel == 3) {
      tela = 9;
    }
  } else if (tela == 9 && jNext.estaSobre ()) { // Tela de próximo nível e botão continuar
    inicializarJogo (); // Reinicia o jogo
    if (nivel == 1) {
      tela = 4;
    } else if (nivel == 2) {
      tela = 8;
    } else if (nivel == 3) {
      tela = 9;
    }
  } else if (tela == 6 && botaoBack.estaSobre ()) { // Se estiver na tela de game over e carregar no botão voltar
    tela = 2; // Vai para a tela de níveis
  } else if (tela == 7 && botaoBack.estaSobre ()) { // Se estiver na tela de próximo nível e carregar no botão voltar
    tela = 2; // Vai para a tela de níveis
  }
}


void keyPressed() {
  if (tela == 4 || tela == 8 || tela == 9) { // nos níveis
    float jogadorX = 0;
    float jogadorY = 0;

    if (personagemEscolhido.equals("gato")) {
      jogadorX = gato.x;
      jogadorY = gato.y;
    } else if (personagemEscolhido.equals("pato")) {
      jogadorX = pato.x;
      jogadorY = pato.y;
    } else if (personagemEscolhido.equals("penguim")) {
      jogadorX = penguim.x;
      jogadorY = penguim.y;
    }

    if (key == 'e' || key == 'E') { // por exemplo, a tecla E
      // for (int i = 0; i < velas.length; i++) {
      // velas[i].tentarAcender(jogadorX, jogadorY);
      PVector p = posJogador();
      for (Vela v : velas) v.tentarAcender(p.x, p.y);
    }
  }
}
void mouseReleased() {
  // Só queremos fazer algo se o cursor ainda estiver sobre o botão Back
  if (!botaoBack.estaSobre()) return;

  //  Decide para onde voltar consoante a tela actual
  switch (tela) {
  case 2:   // ecrã de Níveis
  case 3:   // Instruções
  case 5:   // Escolha de Personagem
    tela = 1;      //  Menu principal
    break;

  case 6:   // Game Over
  case 7:   // Next Level
    tela = 2;      //  Ecrã de Níveis
    break;
  }
}
// tela 0
void desenharInicial () {
  image (inicio, 0, 0, width, height);
  botaoInicio.desenharBotao ();
}

// tela 1
void desenharMenu () {
  image (screen, 0, 0, width, height);
  botaoMenu.desenharBotao ();
  botaoNiveis.desenharBotao ();
  botaoInstrucoes.desenharBotao ();
}

// tela 2
void desenharNiveis () {
  image (screen, 0, 0, width, height);
  n1.desenharBotao ();
  n2.desenharBotao ();
  n3.desenharBotao ();
  botaoBack.desenharBotao ();
}

// tela 3
void desenharInstrucoes () {
  image (screen, 0, 0, width, height);
  background (255, 0, 0);
  botaoBack.desenharBotao ();
}

void geralNiveis () {

  // inicializarJogo ();
  if (personagemEscolhido.equals ("gato")) {
    gato.moveredesenhar();
  } else if (personagemEscolhido.equals ("pato")) {
    pato.moveredesenhar();
  } else if (personagemEscolhido.equals ("penguim")) {
    penguim.moveredesenhar();
  }

  // Verifica colisão com o velho para passar de nível
  float jogadorX = 0;
  float jogadorY = 0;

  if (personagemEscolhido.equals ("gato")) {
    jogadorX = gato.x;
    jogadorY = gato.y;
  } else if (personagemEscolhido.equals ("pato")) {
    jogadorX = pato.x;
    jogadorY = pato.y;
  } else if (personagemEscolhido.equals ("penguim")) {
    jogadorX = penguim.x;
    jogadorY = penguim.y;
  }
  if (velho != null) {
    // persegue o jogador
    PVector p = posJogador();
    velho.perseguir(p.x, p.y);
    velho.moveredesenhar();
    if (dist(jogadorX, jogadorY, velho.x + 67, velho.y + 75) < 50) {   // 67/75 ~ centro do sprite
      tela = 6;     // gameover
    }
  }

  for (int i = 0; i < velas.length; i++) {
    // velas[i].desenhar();
    for (Pedra ped : pedras) ped.desenhar();
   actualizarVelas();
    //— barra de energia
    desenharBarraEnergia();
  }
}


void desenharBarraEnergia () {
  tempo -= 0.04;
  if (tempo<=0) {
    tela=6;
    return;
  }
  noStroke ();
  fill (255); // cor branco
  rect (10, 10, tempo * 2, 20, 10); // barra de energia
  textSize (20); // tamanho da fonte
  text (int (tempo), 240, 28); // texto
}

void actualizarVelas() {
  // posição actual do jogador
  float jx = 0, jy = 0;
  if (personagemEscolhido.equals("gato")) {
    jx = gato.x;
    jy = gato.y;
  } else if (personagemEscolhido.equals("pato")) {
    jx = pato.x;
    jy = pato.y;
  } else if (personagemEscolhido.equals("penguim")) {
    jx = penguim.x;
    jy = penguim.y;
  }

  // acender se E estiver premida
  if (keyPressed && (key == 'e' || key == 'E')) {
    for (Vela v : velas) v.tentarAcender(jx, jy);
  }

  // desenhar todas
  for (Vela v : velas) v.desenhar();
}

void selecionarNivel(int numNivel) {
  // Se nenhum personagem foi escolhido, vai para a tela de personagens para escolher um
  if (personagemEscolhido.equals("")) {
    tela = 5; // Vai para a tela de seleção de personagens
  } else {
    // Se um personagem foi escolhido, inicializa o jogo e vai para o nível correto
    inicializarJogo();
    if (numNivel == 1) {
      tela = 4; // Vai para o nível 1
    } else if (numNivel == 2) {
      tela = 8; // Vai para o nível 2
    } else if (numNivel == 3) {
      tela = 9; // Vai para o nível 3
    }
  }
}
PVector posJogador() {
  if (personagemEscolhido.equals("gato"))
    return new PVector(gato.x+gato.largura/2, gato.y+gato.altura/2);
  if (personagemEscolhido.equals("pato"))
    return new PVector(pato.x+pato.largura/2, pato.y+pato.altura/2);
  return new PVector(penguim.x+penguim.largura/2, penguim.y+penguim.altura/2);
}

boolean caminhoLivre(float cx, float cy) {

  // fora da imagem -> é parede
  if (cx < 0 || cy < 0 || cx >= maskLabirinto.width || cy >= maskLabirinto.height)
    return false;

  color pixel = maskLabirinto.get(int(cx), int(cy));
  return brightness(pixel) < 60;   //  chão cinza escuro (podes ajustar 60)
}

/*  teste de colisão para sprites rectangulares  */
boolean podeMover(float nx, float ny, float w, float h) {
  return caminhoLivre(nx+5, ny+5) &&
    caminhoLivre(nx+w-5, ny+5) &&
    caminhoLivre(nx+5, ny+h-5) &&
    caminhoLivre(nx+w-5, ny+h-5);
}

// NIVEIS
// tela 4
void desenharNivel1 () {
    nivel = 1;
   pushMatrix();
  if (tremorCounter > 0) {
    translate(random(-SHAKE_MAG, SHAKE_MAG), random(-SHAKE_MAG, SHAKE_MAG));
    tremorCounter--;
  }
  image(maskLabirinto, 0, 0, width, height);   // (ou background)
  
  tempo -= 0.04; 
  // se a energia acabar
  if (tempo <= 0) {
    popMatrix();
    tela = 6; // vai para o modo fim do jogo
    return; // interrompe a funcao desenhar jogo
  }
 
  geralNiveis ();
   popMatrix(); 
}
 /* for (int p = 0; p < pedras.length; p ++) {
    pedras [p].desenhar ();
  }
  desenharBarraEnergia ();       
} */
// tela 8
void desenharNivel2 () {
  nivel = 2;
  image(maskLabirinto, 0, 0, width, height);
  //  background (0, 255, 0);
  geralNiveis ();
}

// tela 9
void desenharNivel3 () {
  nivel = 3;
  background (0, 255, 0);
  geralNiveis ();
}

// tela 5
void desenharPersonagens () {
  image (carascreen, 0, 0, width, height);
  fill (#F5B400);
  stroke (#98722B);
  strokeWeight (7);
  if (personagemEscolhido.equals ("gato")) {
    ellipse (botaoGato.x + 105, botaoGato.y - 170, botaoGato.largura + 20, botaoGato.altura + 120);
  } else if (personagemEscolhido.equals("pato")) {
    ellipse (botaoPato.x + 105, botaoPato.y - 170, botaoPato.largura + 20, botaoPato.altura + 120);
  } else if (personagemEscolhido.equals("penguim")) {
    ellipse (botaoPenguim.x + 105, botaoPenguim.y - 170, botaoPenguim.largura + 20, botaoPenguim.altura + 120);
  }

  image (gato_frente, width / 2 - 450, 350, 150, 160);
  botaoGato.desenharBotao ();
  image (pato_frente, width / 2 - 75, 350, 150, 160);
  botaoPato.desenharBotao ();
  image (penguim_frente, width / 2 + 300, 350, 150, 160);
  botaoPenguim.desenharBotao ();
  botaoJogar.desenharBotao ();
  botaoBack.desenharBotao ();
}

// tela 6
void desenharPerder () {
  image (again, 0, 0, width, height);
  jOutraVez.desenharBotao ();
  botaoBack.desenharBotao ();
}

// tela 7
void desenharProxNiv () {
  image (next, 0, 0, width, height);
  jNext.desenharBotao ();
  botaoBack.desenharBotao ();
}

// colidir com pedras
void colisaoPedras () {
  float x = 0, y = 0;

  if (personagemEscolhido.equals ("gato")) {
    x = gato.x;
    y = gato.y;
  } else if (personagemEscolhido.equals ("pato")) {
    x = pato.x;
    y = pato.y;
  } else if (personagemEscolhido.equals ("penguim")) {
    x = penguim.x;
    y = penguim.y;
  }

    PVector p = posJogador();
  for (Pedra ped : pedras) {
    if (dist(p.x, p.y, ped.x, ped.y) < 40) {
      tempo -= 1;
      tremorCounter = SHAKE_FRAMES;     // dispara tremor
    }
  }
}
