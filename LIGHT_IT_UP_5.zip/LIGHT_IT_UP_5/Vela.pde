class Vela {
  float x, y;
  boolean acesa;

  Vela(float x, float y) {
    this.x = x;
    this.y = y;
    this.acesa = false;
  }

  void tentarAcender(float jogadorX, float jogadorY) {
    if (!acesa && dist(jogadorX, jogadorY, x, y) < 50) {
      acesa = true;
    }
  }

  void desenhar() {
    if (acesa) {
      image(vela_acesa, x, y, 50, 70);
    } else {
      image(vela_apagada, x, y, 50, 70);
    }
  }
}
