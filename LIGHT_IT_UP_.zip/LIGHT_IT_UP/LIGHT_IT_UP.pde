
// BOTOES
Botoes botaoMenu, botaoNiveis, botaoInstrucoes, botaoBack, botaoInicio, jOutraVez;
Botoes botaoGato, botaoPato, botaoPenguim, botaoJogar;
Botoes n1, n2, n3;

// IMAGENS
PImage gato_frente, gato_costas, gato_direita, gato_esquerda, bgato;
PImage pato_frente, pato_costas, pato_direita, pato_esquerda, bpato;
PImage penguim_frente, penguim_costas, penguim_direita, penguim_esquerda, bpenguim;
PImage vela_acesa, vela_apagada;
PImage velho_frente, velho_costas, velho_direita, velho_esquerda;
PImage inicio, botaoI, screen, carascreen, play, niveis, howto, back, b1, b2, b3, again;
PImage pedrinha;

// CLASSES
Gato gato;
Pato pato;
Penguim penguim;
Velho velho;
Pedra [] pedras = new Pedra [5];

// OUTROS
int tela = 0;
String personagemEscolhido = "";
float tempo = 100; // inicio da energia

void setup () {
  size (1300, 800);
  // IMAGENS
  gato_frente = loadImage ("gato_frente.png");
  gato_costas = loadImage ("gato_costas.png");
  gato_direita = loadImage ("gato_direita.png");
  gato_esquerda = loadImage ("gato_esquerda.png");
  pato_frente = loadImage ("pato_frente.png");
  pato_costas = loadImage ("pato_costas.png");
  pato_direita = loadImage ("pato_direita.png");
  pato_esquerda = loadImage ("pato_esquerda.png");
  penguim_frente = loadImage ("pinguim_frente.png");
  penguim_costas = loadImage ("pinguim_costas.png");
  penguim_direita = loadImage ("pinguim_direita.png");
  penguim_esquerda = loadImage ("pinguim_esquerda.png");
  vela_acesa = loadImage ("vela_acesa.png");
  vela_apagada = loadImage ("vela_apagada.png");
  velho_frente = loadImage ("velho_frente.png");
  velho_costas = loadImage ("velho_costas.png");
  velho_direita = loadImage ("velho_direita.png");
  velho_esquerda = loadImage ("velho_esquerda.png");
  pedrinha = loadImage ("pedra.png");

  inicio = loadImage ("main screen.jpg");
  botaoI = loadImage ("botão_main.png");
  screen = loadImage ("loadingscreen.jpg");
  carascreen = loadImage ("characterscreen.jpg");
  play = loadImage ("play_btn.png");
  niveis = loadImage ("levels_btn.png");
  howto = loadImage ("howtoplay_btn.png");
  back = loadImage ("back_button.png");
  b1 = loadImage ("lvl1_btn.png");
  b2 = loadImage ("lvl2_btn.png");
  b3 = loadImage ("lvl3_btn.png");
  bgato = loadImage ("gato_btn.png");
  bpato = loadImage ("pato_btn.png");
  bpenguim = loadImage ("pingu_btn.png");

  gato = new Gato (100, 100, 10, 70, 80);
  pato = new Pato (180, 100, 10, 70, 80);
  penguim = new Penguim (260, 100, 15, 70, 80);
  velho = new Velho (width / 2, random (50, height - 50), 2);

  // BOTOES
  botaoMenu = new Botoes (width / 2 - 150, height / 2 - 150, 70, 250, play);
  botaoNiveis = new  Botoes (width / 2 - 150, height / 2, 70, 250, niveis);
  botaoInstrucoes = new Botoes (width / 2 - 150, height / 2 + 150, 70, 250, howto);
  n1 = new Botoes (width / 2 - 150, height / 2 - 150, 70, 250, b1);
  n2 = new Botoes (width / 2 - 150, height / 2, 70, 250, b2);
  n3 = new Botoes (width / 2 - 150, height / 2 + 150, 70, 250, b3);
  botaoGato = new Botoes (width / 2 - 480, height / 2 + 190, 80, 200, bgato);
  botaoPato = new Botoes (width / 2 - 105, height / 2 + 190, 80, 200, bpato);
  botaoPenguim = new Botoes (width / 2 + 270, height / 2 + 190, 80, 200, bpenguim);
  botaoJogar = new Botoes (width / 2 - 105, height / 2 + 290, 80, 200, play);
  botaoBack = new Botoes (20, 20, 40, 40, back);
  botaoInicio = new Botoes (width / 2 - 265, height / 2 + 170, 103, 520, botaoI);
  jOutraVez = new Botoes (width / 2 - 150, height / 2 + 150, 70, 250, howto);

  geralNiveis ();
}

void draw () {
  if (tela == 0) {
    desenharInicial ();
  } else if (tela == 1) { // menu
    desenharMenu ();
  } else if (tela == 2) { // menu niveis
    desenharNiveis ();
  } else if (tela == 3) { // instrucoes / how to play
    desenharInstrucoes ();
  } else if (tela == 4) { // nivel 1
    desenharNivel1 ();
  } else if (tela == 5) { // diferentes personagens
    desenharPersonagens ();
  } else if (tela == 6) {
    desenharPerder ();
  }
}

void mousePressed () {
  if (tela == 0 && botaoInicio.estaSobre ()) {
    tela = 1;
  } else if (tela == 1 && botaoMenu.estaSobre ()) {
    tela = 5;
  } else if (tela == 5) {
    if (botaoGato.estaSobre()) {
      personagemEscolhido = "gato";
    } else if (botaoPato.estaSobre()) {
      personagemEscolhido = "pato";
    } else if (botaoPenguim.estaSobre()) {
      personagemEscolhido = "penguim";
    } else if (tela == 5 && botaoJogar.estaSobre() && !personagemEscolhido.equals ("")) {
      tela = 4;
    }
  } else if (tela == 1 && botaoNiveis.estaSobre ()) {
    tela = 2;
  } else if (tela == 2 && botaoBack.estaSobre ()) {
    tela = 1;
  } else if (tela == 1 && botaoInstrucoes.estaSobre ()) {
    tela = 3;
  } else if (tela == 3 && botaoBack.estaSobre ()) {
    tela = 1;
  } else if (tela == 2 && n1.estaSobre ()) {
    tela = 4;
  } else if (tela == 5 && botaoBack.estaSobre ()) {
    tela = 1;
  }
}

void desenharInicial () {
  image (inicio, 0, 0, width, height);
  botaoInicio.desenharBotao ();
}

void desenharMenu () {
  image (screen, 0, 0, width, height);
  botaoMenu.desenharBotao ();
  botaoNiveis.desenharBotao ();
  botaoInstrucoes.desenharBotao ();
}

void desenharNiveis () {
  image (screen, 0, 0, width, height);
  n1.desenharBotao ();
  n2.desenharBotao ();
  n3.desenharBotao ();
  botaoBack.desenharBotao ();
}

void desenharInstrucoes () {
  background (255, 0, 0);
  //botaoBack.desenharBotao ();
}

void geralNiveis () {
  desenharBarraEnergia ();
  tempo -= 0.04; // vai dinimuinto a energia
  // se a energia acabar
  if (tempo <= 0) {
    tela = 6; // vai para o modo fim do jogo
    return; // interrompe a funcao desenhar jogo
  }
  if (personagemEscolhido.equals ("gato")) {
    gato.moveredesenhar();
  } else if (personagemEscolhido.equals ("pato")) {
    pato.moveredesenhar();
  } else if (personagemEscolhido.equals ("penguim")) {
    penguim.moveredesenhar();
  }

  // repeticao e declaracao das pedras
  for (int p = 0; p < pedras.length; p ++) {
    pedras [p] = new Pedra(random(50, width - 50), random(50, height-50));
  }
}

void desenharBarraEnergia () {
  noStroke ();
  fill (255); // cor branco
  rect (10, 10, tempo * 2, 20, 10); // barra de energia
  textSize (20); // tamanho da fonte
  text (int (tempo), 240, 28); // texto
}

void desenharNivel1 () {
  background (0, 255, 0);
  geralNiveis ();
  for (int p = 0; p < pedras.length; p ++) {
    pedras [p].desenhar ();
  }
  velho.moveredesenhar ();
}

void desenharPersonagens () {
  image (carascreen, 0, 0, width, height);
  fill (#F5B400);
  stroke (#98722B);
  strokeWeight (7);
  if (personagemEscolhido.equals ("gato")) {
    ellipse (botaoGato.x + 105, botaoGato.y - 170, botaoGato.largura + 20, botaoGato.altura + 120);
  } else if (personagemEscolhido.equals("pato")) {
    ellipse (botaoPato.x + 105, botaoPato.y - 170, botaoPato.largura + 20, botaoPato.altura + 120);
  } else if (personagemEscolhido.equals("penguim")) {
    ellipse (botaoPenguim.x + 105, botaoPenguim.y - 170, botaoPenguim.largura + 20, botaoPenguim.altura + 120);
  }

  image (gato_frente, width / 2 - 450, 350, 150, 160);
  botaoGato.desenharBotao ();
  image (pato_frente, width / 2 - 75, 350, 150, 160);
  botaoPato.desenharBotao ();
  image (penguim_frente, width / 2 + 300, 350, 150, 160);
  botaoPenguim.desenharBotao ();
  botaoJogar.desenharBotao ();
  botaoBack.desenharBotao ();
}

void desenharPerder () {
  image (screen, 0, 0, width, height);
}
