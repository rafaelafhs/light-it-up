class Pedra {
  float x;
  float y;
  boolean penalizado;
  
  Pedra (float x, float y){
  this.x = x;
  this.y = y;
  this.penalizado= false;
  }
  
  //desenho
  void desenhar () {
    image(pedrinha, x, y, 80, 65);
  }
}
