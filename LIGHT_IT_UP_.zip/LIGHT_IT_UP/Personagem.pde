class Gato {
  float x;
  float y;
  float largura;
  float altura;
  float velocidade;

  Gato (float x, float y, float velocidade, float largura, float altura) {
    this.x = x;
    this.y = y;
    this.velocidade = velocidade;
    this.largura = largura;
    this.altura = altura;
  }

  // mover personagem
  void moveredesenhar () {
    // mover com as setas e letras wasd
    image (gato_frente, x, y, largura, altura);
    if (keyPressed) {
      if (keyCode == UP || key == 'w') {
        image (gato_costas, x, y, largura, altura);
        y -= velocidade; // sobe
      } else if (keyCode == DOWN || key == 's') {
        image (gato_frente, x, y, largura, altura);
        y += velocidade; // desce
      } else if (keyCode == LEFT || key == 'a') {
        image (gato_esquerda, x, y, largura, altura);
        x -= velocidade; // esquerda
      } else if (keyCode == RIGHT || key == 'd') {
        image (gato_direita, x, y, largura, altura);
        x += velocidade; // direita
      }
    }
  }
}

class Pato {
  float x;
  float y;
  float largura;
  float altura;
  float velocidade;

  Pato (float x, float y, float velocidade, float largura, float altura) {
    this.x = x;
    this.y = y;
    this.velocidade = velocidade;
    this.largura = largura;
    this.altura = altura;
  }

  // mover personagem
  void moveredesenhar () {
    // mover com as setas e letras wasd
    image (pato_frente, x, y, largura, altura);
    if (keyPressed) {
      if (keyCode == UP || key == 'w') {
        image (pato_costas, x, y, largura, altura);
        y -= velocidade; // sobe
      } else if (keyCode == DOWN || key == 's') {
        image (pato_frente, x, y, largura, altura);
        y += velocidade; // desce
      } else if (keyCode == LEFT || key == 'a') {
        image (pato_esquerda, x, y, largura, altura);
        x -= velocidade; // esquerda
      } else if (keyCode == RIGHT || key == 'd') {
        image (pato_direita, x, y, largura, altura);
        x += velocidade; // direita
      }
    }
  }
}

class Penguim {
  float x;
  float y;
  float largura;
  float altura;
  float velocidade;

  Penguim (float x, float y, float velocidade, float largura, float altura) {
    this.x = x;
    this.y = y;
    this.velocidade = velocidade;
    this.largura = largura;
    this.altura = altura;
  }

  // mover personagem
  void moveredesenhar () {
    // mover com as setas e letras wasd
    image (penguim_frente, x, y, largura, altura);
    if (keyPressed) {
      if (keyCode == UP || key == 'w') {
        image (penguim_costas, x, y, largura, altura);
        y -= velocidade; // sobe
      } else if (keyCode == DOWN || key == 's') {
        image (penguim_frente, x, y, largura, altura);
        y += velocidade; // desce
      } else if (keyCode == LEFT || key == 'a') {
        image (penguim_esquerda, x, y, largura, altura);
        x -= velocidade; // esquerda
      } else if (keyCode == RIGHT || key == 'd') {
        image (penguim_direita, x, y, largura, altura);
        x += velocidade; // direita
      }
    }
  }
}
