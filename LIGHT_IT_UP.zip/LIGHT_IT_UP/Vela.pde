class Vela {
  float x;
  float y; 
  boolean acesa; 
  
  Vela (float x, float y) {
    this.x = x;
    this.y = y;
    this.acesa = false;
  }
  
  // desenhar velas
  void desenhar () {
    if (acesa) {
      image (vela_acesa, x, y, 50, 50); 
    } else { // se não 
      image (vela_apagada, x, y, 40, 40); 
    }
  }
  
  // acender vela
  void acender () {
    acesa = true;
  }
}  
