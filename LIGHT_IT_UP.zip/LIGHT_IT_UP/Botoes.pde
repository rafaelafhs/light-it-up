class Botoes {
  float x;
  float y;
  float altura;
  float largura;
  PImage img;

  Botoes(float x, float y, float altura, float largura, PImage img) {
    this.x = x;
    this.y = y;
    this.altura = altura;
    this.largura = largura;
    this.img = img;
  }

  // Verifica se o mouse está sobre o botão
  boolean estaSobre() {
    return mouseX > x && mouseX < x + largura && mouseY > y && mouseY < y + altura;
  }

  // Desenha o botão com a imagem
  void desenharBotao() {
    image(img, x, y, largura, altura);
  }
}
